local M = {}

local cooldown = 0
local nextToggleTime = math.random(30, 90)
local rainActive = false
local soundObj = nil
local vol = 1.0  -- Default volume

local function onUpdate(dt)
  cooldown = cooldown + dt
  if cooldown < nextToggleTime then return end
  cooldown = 0
  nextToggleTime = math.random(30, 90)

  local rain = scenetree.findObject("rain_coverage") or scenetree.findObject("WCA_rain") or scenetree.findObject("rain_single_drops")
  if not rain then
    log("E", "dynamicRain", "No rain object found in the scene.")
    return
  end

  if not rainActive then
    local drops = math.random(500, 1000)
    rain:setField("numDrops", 0, drops)
    rain:postApply()

    -- Create rain sound
    local existing = scenetree.findObject("rain_sound")
    if existing then
      existing:delete()
    end

    soundObj = createObject("SFXEmitter")
    soundObj.scale = Point3F(100, 100, 100)
    soundObj.fileName = String('/art/sound/environment/amb_rain_medium.ogg')
    soundObj.playOnAdd = true
    soundObj.isLooping = true
    soundObj.volume = vol
    soundObj.isStreaming = true
    soundObj.is3D = false
    soundObj:registerObject("rain_sound")

    rainActive = true
    log("I", "dynamicRain", "Rain started with " .. drops .. " drops")
  else
    rain:setField("numDrops", 0, 0)
    rain:postApply()

    -- Stop sound
    local existing = scenetree.findObject("rain_sound")
    if existing then
      existing:delete()
    end

    rainActive = false
    log("I", "dynamicRain", "Rain stopped")
  end
end

M.onUpdate = onUpdate
return M
